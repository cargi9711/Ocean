function showMessage() {
    const facts = [
        "The Pacific Ocean is the largest ocean on Earth.",
        "More than 80% of the ocean is unexplored.",
        "The Mariana Trench is the deepest part of the ocean.",
        "Coral reefs are known as the rainforests of the sea."
    ];
    const randomFact = facts[Math.floor(Math.random() * facts.length)];
    document.getElementById("fact").innerText = randomFact;
}
